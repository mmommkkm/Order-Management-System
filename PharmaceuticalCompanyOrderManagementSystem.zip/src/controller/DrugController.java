package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.DrugVO;

public class DrugController implements Initializable {
	@FXML
	private TableView<DrugVO> tableView = new TableView<>();
	@FXML
	private TextField txtdrugNum;
	@FXML
	private TextField txtItem;
	@FXML
	private ComboBox<String> cbStandard;
	@FXML
	private TextField txtVatBasePrice;
	@FXML
	private Button btnRegist;
	@FXML
	private Button btnExit;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnChange;
	@FXML
	private TextField txtSearch;
	@FXML
	private Button btnSearch;
	@FXML
	private Button btnAll;
	@FXML
	private Button btnInit;

	DrugVO drug = new DrugVO();
	ObservableList<DrugVO> data = FXCollections.observableArrayList();
	ObservableList<DrugVO> selectDrug = FXCollections.observableArrayList();
	int selectedIndex;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		cbStandard.setItems(
				FXCollections.observableArrayList("30C", "100C", "500C", "28T", "30T", "100T", "300T", "500T", "IV"));
		btnRegist.setOnAction(event -> handlerRegistAction(event));
		btnExit.setOnAction(event -> handlerExitAciton(event));
		btnDelete.setOnAction(event -> handlerDeleteAction(event));
		btnChange.setOnAction(event -> handlerChangeAction(event));
		btnSearch.setOnAction(event -> handlerSearchAction(event));
		btnAll.setOnAction(event -> handlerAllAction(event));
		btnInit.setOnAction(event -> handlerInitAction(event));

		tableView.setEditable(false);
		tableView.setItems(data);

		TableColumn colNo = new TableColumn("��ǰǥ���ڵ�");
		colNo.setMinWidth(137);
		colNo.setStyle("-fx-alignment:CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("d_num"));

		TableColumn colItem = new TableColumn("��ǰ");
		colItem.setMinWidth(137);
		colItem.setStyle("-fx-alignment:CENTER");
		colItem.setCellValueFactory(new PropertyValueFactory<>("item"));

		TableColumn colStandard = new TableColumn("ǰ�� �� �԰�");
		colStandard.setMinWidth(137);
		colStandard.setStyle("-fx-alignment:CENTER");
		colStandard.setCellValueFactory(new PropertyValueFactory<>("Standard"));

		TableColumn colVat = new TableColumn("���ؾ�ǰ����(VAT)");
		colVat.setMinWidth(137);
		colVat.setStyle("-fx-alignment:CENTER");
		colVat.setCellValueFactory(new PropertyValueFactory<>("vatbaseprice"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colNo, colItem, colStandard, colVat);

		totalList();

		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {

			public void handle(MouseEvent arg0) {
				try {
					txtdrugNum.setText(tableView.getSelectionModel().getSelectedItem().getD_num());
					txtItem.setText(tableView.getSelectionModel().getSelectedItem().getItem());
					cbStandard.getSelectionModel()
							.select(tableView.getSelectionModel().getSelectedItem().getStandard());
					txtVatBasePrice.setText(tableView.getSelectionModel().getSelectedItem().getVatbaseprice() + "");
				} catch (Exception e) {
					System.out.println(e);
				}

			}

		});
	}

	public void handlerInitAction(ActionEvent event) {
			init();
	}

	public void handlerAllAction(ActionEvent event) {
		try {
			data.remove(data);
			totalList();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerSearchAction(ActionEvent event) {
		DrugVO dvo = new DrugVO();
		DrugDAO dDao = new DrugDAO();

		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txtSearch.getText();
			dvo = dDao.getDrugCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText("��ǰ ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (dvo != null)) {
				ArrayList<String> title;
				ArrayList<DrugVO> list;

				title = dDao.getColumnName();
				int columnCount = title.size();

				list = dDao.getDrugTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (dvo.getItem().equals(searchName)) {
					txtSearch.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						dvo = list.get(index);
						if (dvo.getItem().equals(searchName)) {
							data.add(dvo);
							searchResult = true;
						}
					}
				}
			}

			if (!searchResult) {
				txtSearch.clear();
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("��ǰ ���� �˻�");
				alert.setHeaderText(searchName + "��ǰ ������ ã�� �� �����ϴ�");
				alert.setContentText("�ٽ� �˻����ּ���!");
				alert.showAndWait();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("��ǰ ���� �˻� ����");
			alert.setHeaderText("��ǰ ������ ���� �� �� �����ϴ�");
			alert.setContentText("�ٽ� �˻����ּ���!");
			alert.showAndWait();
		}

	}

	public void totalList() {

		Object[][] totalData;

		DrugDAO dDao = new DrugDAO();
		DrugVO dVo = null;

		ArrayList<String> title;
		ArrayList<DrugVO> list;

		title = dDao.getColumnName();
		int columnCount = title.size();

		list = dDao.getDrugTotal();

		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			dVo = list.get(index);
			data.add(dVo);
		}
	}

	public void handlerChangeAction(ActionEvent event) {
		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/drugchange.fxml"));
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnRegist.getScene().getWindow());
			dialog.setTitle("��ǰ ���� ����");

			Parent parentEdit = (Parent) loader.load();
			DrugVO drugChange = tableView.getSelectionModel().getSelectedItem();
			selectedIndex = tableView.getSelectionModel().getSelectedIndex();

			TextField ChangeNum = (TextField) parentEdit.lookup("#txtDrugNum");
			TextField ChangeItem = (TextField) parentEdit.lookup("#txtItem");
			ComboBox<String> ChangeStandard = (ComboBox) parentEdit.lookup("#cbStandard");
			TextField ChangeVatBasePric = (TextField) parentEdit.lookup("#txtVatBasePrice");

			ChangeNum.setDisable(true);
			ChangeItem.setDisable(true);
			ChangeStandard.setDisable(true);

			ChangeNum.setText(drugChange.getD_num());
			ChangeItem.setText(drugChange.getItem());
			ChangeStandard.setItems(FXCollections.observableArrayList("30C", "100C", "500C", "28T", "30T", "100T",
					"300T", "500T", "IV"));
			ChangeStandard.getSelectionModel().select(drugChange.getStandard());
			ChangeVatBasePric.setText(drugChange.getVatbaseprice() + "");

			Button btnRegistAdd = (Button) parentEdit.lookup("#btnRegist");
			Button btnExitAdd = (Button) parentEdit.lookup("#btnExit");

			btnRegistAdd.setOnAction(e -> {
				if (ChangeNum.getText().equals("") || ChangeItem.getText().equals("")
						|| ChangeStandard.getSelectionModel().isEmpty() || ChangeVatBasePric.getText().equals("")) {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("��ǰ ���");
					alert.setHeaderText("��ǰ ������ ��Ȯ�� �Է��Ͻÿ�");
					alert.setContentText("��ǰ ��� Ȯ�����ּ���!");
					alert.showAndWait();

				} else {
					DrugVO dvo = new DrugVO();
					DrugDAO dDao = new DrugDAO();

					try {
						dvo = new DrugVO(ChangeNum.getText(), ChangeItem.getText(),
								ChangeStandard.getSelectionModel().getSelectedItem().toString(),
								Integer.parseInt(ChangeVatBasePric.getText()));
						dDao.getDrugUpdate(dvo, dvo.getD_num());
						data.removeAll(data);
						totalList();
						dialog.close();
						init();
					} catch (Exception e1) {
						System.out.println(e1);

					}
				}

			});
			btnExitAdd.setOnAction(e -> {
				dialog.close();
			});
			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);// ũ�������Ұ�
			dialog.show();
		} catch (Exception e) {
			System.out.println(e);

		}
	}

	public void handlerDeleteAction(ActionEvent event) {
		DrugDAO dDao = new DrugDAO();
		try {

			dDao.getDrugDelete(tableView.getSelectionModel().getSelectedItem().getD_num());
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void handlerExitAciton(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
			Scene scene = new Scene(root);
			Stage primaryStage = new Stage();

			Stage oldStage = (Stage) btnRegist.getScene().getWindow();
			oldStage.close();
			primaryStage.setTitle("�ѱ����� �ֹ�����");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void init() {
		txtdrugNum.clear();
		txtdrugNum.setEditable(true);
		txtItem.clear();
		txtItem.setEditable(true);
		cbStandard.getSelectionModel().clearSelection();
		cbStandard.setEditable(true);
		txtVatBasePrice.clear();
		txtVatBasePrice.setEditable(true);
	}

	public void handlerRegistAction(ActionEvent event) {
		try {
			data.removeAll(data);
			DrugVO drv = null;
			DrugDAO dDao = null;
			int i = 0;

			if (event.getSource().equals(btnRegist)) {
				drv = new DrugVO(txtdrugNum.getText().trim(), txtItem.getText().trim(),
						cbStandard.getSelectionModel().getSelectedItem(), Integer.parseInt(txtVatBasePrice.getText().trim()));
				dDao = new DrugDAO();
				i = dDao.getDruginput(drv);
				if (i == 1) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��ǰ ���");
					alert.setHeaderText("��ǰ ��� ����");
					alert.setContentText("��ǰ ��� ����!!!");
					alert.showAndWait();
					
					
				} else {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("��ǰ ���");
					alert.setHeaderText("��ǰ ��� ����");
					alert.setContentText("��ǰ ��� ����!!!");
					alert.showAndWait();

				}
			}
			init();
			totalList();
		} catch (Exception e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("��ǰ ���");
			alert.setHeaderText("��ǰ ��� ����");
			alert.setContentText("��ǰ ��� ����!!!");
			alert.showAndWait();

		}

	}
}
