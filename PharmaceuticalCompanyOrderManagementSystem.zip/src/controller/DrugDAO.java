package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.DrugVO;
import model.StoreVO;

public class DrugDAO {
	
	public int getDruginput(DrugVO dvo) {
		String sql = "insert into company_drug" + " values " + "(?, ?, ?, ?)";
		int i = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dvo.getD_num());
			pstmt.setString(2, dvo.getItem());
			pstmt.setString(3, dvo.getStandard());
			pstmt.setInt(4, dvo.getVatbaseprice());

			i = pstmt.executeUpdate();

		} catch (SQLException e) {

		} catch (Exception e) {

		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return i;
	}
	public DrugVO getDrugCheck(String item) throws Exception {
		String sql = "select * from company_drug where item = '" + item + "'";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		DrugVO dvo = null;

		System.out.println(item);
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			/*pstmt.setString(1, item);*/

			rs = pstmt.executeQuery();

			if (rs.next()) {
				dvo = new DrugVO();
				
				dvo.setD_num(rs.getString("d_num"));
				dvo.setItem(rs.getString("item"));
				dvo.setStandard(rs.getString("standard"));
				dvo.setVatbaseprice(rs.getInt("vatbaseprice"));
				
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e1) {
				System.out.println(e1);
			}
		}
		return dvo;
	}
	
	public DrugVO getDrugUpdate(DrugVO dvo, String d_num) throws Exception {
		String sql = "update company_drug set "+ " item = ?, standard = ?, vatbaseprice = ?"
	 + " where d_num = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		DrugVO drvo= null;
		
		try {
			con = DBUtil.getConnection();
			pstmt =con.prepareStatement(sql);

			pstmt.setString(1, dvo.getItem());
			pstmt.setString(2, dvo.getStandard());
			pstmt.setInt(3, dvo.getVatbaseprice());
			pstmt.setString(4, d_num);
	
			int i = pstmt.executeUpdate();
			
			if(i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ����");
				alert.setHeaderText("��ǰ ���� ����");
				alert.setContentText("��ǰ ���� ����!!!");
				alert.showAndWait();

			}else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("��ǰ ����");
				alert.setHeaderText("��ǰ ���� ����");
				alert.setContentText("��ǰ ���� ����!!!");
				alert.showAndWait();

			}
			
		}catch(SQLException e) {
			System.out.println(e);
			
		}catch(Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
		}
		}
			return drvo;
		}
		

	public void getDrugDelete(String no) throws Exception {
		String sql = "Delete from company_drug where d_num = ?";

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, no);
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ǰ ����");
				alert.setHeaderText("��ǰ ���� ����");
				alert.setContentText("��ǰ ���� ����!!!");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("��ǰ ����");
				alert.setHeaderText("��ǰ ���� ����");
				alert.setContentText("��ǰ ���� ����!!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}

	}

	public ArrayList<DrugVO> getDrugTotal() {
		ArrayList<DrugVO> list = new ArrayList<DrugVO>();
		String sql = "select * from company_drug";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		DrugVO drvo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				drvo = new DrugVO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4));
				list.add(drvo);
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return list;
	}

	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from company_drug";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();

			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException e) {

			}
		}

		return columnName;

	}
}
