package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MainController implements Initializable{
	@FXML
	private Button btnStore;
	@FXML
	private Button btnRegist;
	@FXML 
	private Button btnDrug;
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btnStore.setOnAction(event -> handlerBtnStoreAction(event));
		btnRegist.setOnAction(event -> handlerBtnRegistAction(event));
		btnDrug.setOnAction(event -> handlerBtnDrugAction(event));
		
	}


public void handlerBtnDrugAction(ActionEvent event) {
	try {
		Parent root = FXMLLoader.load(getClass().getResource("/view/drug.fxml"));
		Scene scene = new Scene(root);
		Stage primaryStage = new Stage();

		Stage oldStage = (Stage) btnRegist.getScene().getWindow();
		oldStage.close();
		primaryStage.setTitle("��ǰ ���");
		primaryStage.setResizable(false);
		primaryStage.setScene(scene);
		primaryStage.show();
	} catch (Exception e) {
		e.printStackTrace();
	}
}

	public void handlerBtnRegistAction(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/order.fxml"));
			Scene scene = new Scene(root);
			Stage primaryStage = new Stage();

			Stage oldStage = (Stage) btnRegist.getScene().getWindow();
			oldStage.close();
			primaryStage.setTitle("�ֹ����� ���");
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			System.out.println("11111");
			e.printStackTrace();
		}
	}


	public void handlerBtnStoreAction(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/store.fxml"));
			Scene scene = new Scene(root);
			Stage primaryStage = new Stage();

			Stage oldStage = (Stage) btnRegist.getScene().getWindow();
			oldStage.close();
			primaryStage.setTitle("���Ż� ���� ���");
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
