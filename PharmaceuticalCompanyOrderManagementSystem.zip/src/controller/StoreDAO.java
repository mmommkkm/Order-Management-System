package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.StoreVO;

public class StoreDAO {
	public int getStoreVOInformation(StoreVO stv) {
		String sql = "insert into store" + " values " + "(store_seq.nextval, ?, ?, ?, ?, ?)";
		int i = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, stv.getS_name());
			pstmt.setString(2, stv.getS_boss());
			pstmt.setString(3, stv.getS_phone());
			pstmt.setString(4, stv.getS_address());
			pstmt.setString(5, stv.getS_businessnum());

			i = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}

		return i;

	}

	public StoreVO getStoreCheck(String s_name) throws Exception {
		String sql = "select * from store where s_name like ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StoreVO svo = null;

		String i = "%" + s_name + "%";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, i);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				svo = new StoreVO();
				svo.setS_num(rs.getInt("s_num"));
				svo.setS_name(rs.getString("s_name"));
				svo.setS_boss(rs.getString("s_boss"));
				svo.setS_phone(rs.getString("s_phone"));
				svo.setS_address(rs.getString("s_address"));
				svo.setS_businessnum(rs.getString("s_businessnum"));
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e1) {
				System.out.println(e1);
			}
		}
		return svo;
	}

	public StoreVO getStoreUpdate(StoreVO stv, int s_num) throws Exception {
		String dml = "update store set " + " s_name=?, s_boss=?, s_phone=?, s_address=?, s_businessnum=? "
				+ " where s_num = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		StoreVO retval = null;

		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, stv.getS_name());
			pstmt.setString(2, stv.getS_boss());
			pstmt.setString(3, stv.getS_phone());
			pstmt.setString(4, stv.getS_address());
			pstmt.setString(5, stv.getS_businessnum());
			pstmt.setInt(6, s_num);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���Ž� ���� ����");
				alert.setHeaderText("���Ž����� ���� �Ϸ�");
				alert.setContentText("���Ž����� ������ �Ϸ�Ǿ����ϴ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("���Ž� ���� ����");
				alert.setHeaderText("���Ž� ���� ���� ����");
				alert.setContentText("���Ž� ���� ���� ����!!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;
	}

	public ArrayList<StoreVO> getStoreTotal() {
		ArrayList<StoreVO> list = new ArrayList<StoreVO>();
		String tml = "select * from store";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StoreVO stvo = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				stvo = new StoreVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6));
				list.add(stvo);
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return list;
	}

	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from store";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();

			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return columnName;
	}

	public void getStoreDelete(int s_num) throws Exception{
		
		String sql = "delete from store where s_num = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();

			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, s_num);
			
			
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���Ż� ���� ����");
				alert.setHeaderText("���Ż� ���� ���� �Ϸ�");
				alert.setContentText("���Ż� ���� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("���Ż� ����");
				alert.setHeaderText("���Ż� ���� ���� ����");
				alert.setContentText("���Ż� ���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				// 6. �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
	}
}
