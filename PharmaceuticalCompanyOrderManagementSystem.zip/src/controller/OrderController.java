package controller;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.OrderVO;

public class OrderController implements Initializable {
	@FXML
	private TableView<OrderVO> tableView = new TableView<>();
	@FXML
	private TextField txtSName;
	@FXML
	private TextField txtDelivery;
	@FXML
	private TextField txtDestination;
	@FXML
	private DatePicker dpOrderDate;
	@FXML
	private ComboBox<String> cbCollection;
	@FXML
	private TextField txtItem;
	@FXML
	private TextField txtStandard;
	@FXML
	private TextField txtVatBasePrice;
	@FXML
	private ComboBox<Integer> cbS_Num;
	@FXML
	private ComboBox<String> cbD_Num;
	@FXML
	private TextField txtDisCount;
	@FXML
	private TextField txtSell;
	@FXML
	private Button btnSell;
	@FXML
	private TextField txtQuantity;
	@FXML
	private TextField txtTotal;
	@FXML
	private ComboBox<String> cbOrderState;
	@FXML
	private Button btnTotal;
	@FXML
	private Button btnRegist;
	@FXML
	private Button btnExit;
	@FXML
	private DatePicker dpS_Search;
	@FXML
	private DatePicker dpA_Search;
	@FXML
	private TextField txtSearchName;
	@FXML
	private Button btnDateSearch;
	@FXML
	private Button btnChart;
	@FXML
	private Button btnNameSearch;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnStateChange;
	@FXML
	private Button btnInit;
	@FXML
	private Button btnAll;
	@FXML
	private Button btnExcel;
	@FXML
	private Button btnSave;
	@FXML
	private TextField txtSave;

	OrderVO order = new OrderVO();
	ObservableList<OrderVO> data = FXCollections.observableArrayList();
	ObservableList<OrderVO> selectorder = FXCollections.observableArrayList();

	int selectedIndex;
	private Stage primaryStage;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		OrderDAO oDao = new OrderDAO();
		btnExcel.setOnAction(event -> handlerExcelAction(event));
		btnSell.setOnAction(event -> handlerSellAction(event));
		btnTotal.setOnAction(event -> handlerTotalAction(event));
		btnRegist.setOnAction(event -> handlerRegistAction(event));
		btnExit.setOnAction(event -> handlerExitAciton(event));
		btnDelete.setOnAction(event -> handlerDeleteAction(event));
		btnSave.setOnAction(event -> handlerSaveAction(event));
		btnDateSearch.setOnAction(event -> {
			try {
				handlerSearchDateAction(event);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		});
		btnNameSearch.setOnAction(event -> handlerSearchNameAction(event));
		btnChart.setOnAction(event -> handlerViewChartAction(event));
		btnStateChange.setOnAction(event -> handlerStateChangeAction(event));
		btnInit.setOnAction(event -> handlerInitAction(event));
		btnAll.setOnAction(event -> handlerAllAciton(event));
		dpOrderDate.setValue(LocalDate.now());

		cbS_Num.setItems(FXCollections.observableArrayList(oDao.getS_num()));
		cbD_Num.setItems(FXCollections.observableArrayList(oDao.getD_Num()));
		cbCollection.setItems(FXCollections.observableArrayList("������ü����", "����", "�ڵ���ü", "���ι����� ����ī��", "���� �� ������ü",
				"���ھ���", "����ī��", "����"));

		cbOrderState.setItems(FXCollections.observableArrayList("�̽���", "���οϷ�", "��ɻ���"));

		tableView.setEditable(false);
		tableView.setItems(data);
		cbS_Num.setOnAction(event -> handlerCbS_NumAction(event));
		cbD_Num.setOnAction(event -> handlerCbD_NumAction(event));
		/* cbOrderState.setOnAction(event -> handlerOrderStateAction(event)); */
		TableColumn colNo = new TableColumn("NO.");
		colNo.setMinWidth(10);
		colNo.setStyle("-fx-alignment:CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("order_num"));

		TableColumn colSname = new TableColumn("�ŷ�ó��");
		colSname.setMinWidth(120);
		colSname.setStyle("-fx-alignment:CENTER");
		colSname.setCellValueFactory(new PropertyValueFactory<>("s_name"));

		TableColumn colDelivery = new TableColumn("����ó��");
		colDelivery.setMinWidth(100);
		colDelivery.setStyle("-fx-alignment:CENTER");
		colDelivery.setCellValueFactory(new PropertyValueFactory<>("deliveryplace"));

		TableColumn colDestination = new TableColumn("���ó");
		colDestination.setMinWidth(140);
		colDestination.setStyle("-fx-alignment:CENTER");
		colDestination.setCellValueFactory(new PropertyValueFactory<>("destination"));

		TableColumn colDate = new TableColumn("�ֹ�����");
		colDate.setMinWidth(120);
		colDate.setStyle("-fx-alignment:CENTER");
		colDate.setCellValueFactory(new PropertyValueFactory<>("order_date"));

		TableColumn colItem = new TableColumn("��ǰ��");
		colItem.setMinWidth(100);
		colItem.setStyle("-fx-alignment:CENTER");
		colItem.setCellValueFactory(new PropertyValueFactory<>("item"));

		TableColumn colStandard = new TableColumn("�԰�");
		colStandard.setMinWidth(100);
		colStandard.setStyle("-fx-alignment:CENTER");
		colStandard.setCellValueFactory(new PropertyValueFactory<>("standard"));

		TableColumn colCollection = new TableColumn("��������");
		colCollection.setMinWidth(100);
		colCollection.setStyle("-fx-alignment:CENTER");
		colCollection.setCellValueFactory(new PropertyValueFactory<>("collection"));

		TableColumn colCbVatBasePrice = new TableColumn("���ؾ�ǰ����(VAT)");
		colCbVatBasePrice.setMinWidth(150);
		colCbVatBasePrice.setStyle("-fx-alignment:CENTER");
		colCbVatBasePrice.setCellValueFactory(new PropertyValueFactory<>("cbVatBasePrice"));

		TableColumn colDiscount = new TableColumn("������");
		colDiscount.setMinWidth(100);
		colDiscount.setStyle("-fx-alignment:CENTER");
		colDiscount.setCellValueFactory(new PropertyValueFactory<>("discount"));

		TableColumn colSell = new TableColumn("�ǸŰ�");
		colSell.setMinWidth(80);
		colSell.setStyle("-fx-alignment:CENTER");
		colSell.setCellValueFactory(new PropertyValueFactory<>("selling"));

		TableColumn colQuantity = new TableColumn("����");
		colQuantity.setMinWidth(70);
		colQuantity.setStyle("-fx-alignment:CENTER");
		colQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

		TableColumn colTotal = new TableColumn("�հ�ݾ�");
		colTotal.setMinWidth(130);
		colTotal.setStyle("-fx-alignment:CENTER");
		colTotal.setCellValueFactory(new PropertyValueFactory<>("total_money"));

		TableColumn colState = new TableColumn("���λ���");
		colState.setMinWidth(100);
		colState.setStyle("-fx-alignment:CENTER");
		colState.setCellValueFactory(new PropertyValueFactory<>("approvalstatus"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colNo, colSname, colDelivery, colDestination, colDate, colItem, colStandard,
				colCollection, colCbVatBasePrice, colDiscount, colSell, colQuantity, colTotal, colState);

		totalList();

		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent arg0) {
				try {
					txtSName.setText(tableView.getSelectionModel().getSelectedItem().getS_name());
					dpOrderDate.setValue(tableView.getSelectionModel().getSelectedItem().getOrder_date());
					txtDelivery.setText(tableView.getSelectionModel().getSelectedItem().getDeliveryplace());
					txtDestination.setText(tableView.getSelectionModel().getSelectedItem().getDestination());
					cbCollection.getSelectionModel()
							.select(tableView.getSelectionModel().getSelectedItem().getCollection());
					txtItem.setText(tableView.getSelectionModel().getSelectedItem().getItem());
					txtStandard.setText(tableView.getSelectionModel().getSelectedItem().getStandard());
					txtVatBasePrice.setText(tableView.getSelectionModel().getSelectedItem().getCbVatBasePrice() + "");
					cbS_Num.getSelectionModel().select(tableView.getSelectionModel().getSelectedItem().getS_num());
					cbD_Num.getSelectionModel().select(tableView.getSelectionModel().getSelectedItem().getD_num());
					txtSell.setText(tableView.getSelectionModel().getSelectedItem().getSelling() + "");
					txtQuantity.setText(tableView.getSelectionModel().getSelectedItem().getQuantity() + "");
					txtTotal.setText(tableView.getSelectionModel().getSelectedItem().getTotal_money() + "");
					txtDisCount.setText(tableView.getSelectionModel().getSelectedItem().getDiscount() + "");
					cbOrderState.getSelectionModel()
							.select(tableView.getSelectionModel().getSelectedItem().getApprovalstatus());
					cbS_Num.getSelectionModel().select(tableView.getSelectionModel().getSelectedItem().getS_num());
					cbD_Num.getSelectionModel().select(tableView.getSelectionModel().getSelectedItem().getD_num());

				} catch (Exception e) {
					System.out.println(e);

				}

			}

		});

	}

	/*
	 * public void handlerOrderStateAction(ActionEvent event) {
	 * 
	 * if(cbOrderState.getSelectionModel().isEmpty()) { Alert alert = new
	 * Alert(AlertType.ERROR); alert.setTitle("���λ��� ����");
	 * alert.setHeaderText("���λ��¸� �����Ͻÿ�");
	 * alert.setContentText("���λ��¸� Ȯ�����ּ���!"); alert.showAndWait(); }
	 * 
	 * 
	 * }
	 */

	public void handlerSaveAction(ActionEvent event) {
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File selectedDirectory = directoryChooser.showDialog(primaryStage);

		if (selectedDirectory != null) {
			txtSave.setText(selectedDirectory.getAbsolutePath());
			btnExcel.setDisable(false);
		}
	}

	public void handlerExcelAction(ActionEvent event) {
		OrderDAO sDao = new OrderDAO();
		boolean saveSuccess;

		ArrayList<OrderVO> list;
		list = sDao.getOrderTotal();
		OrderExcel excelWriter = new OrderExcel();

		// xlsx ���� ����
		saveSuccess = excelWriter.xlsxWiter(list, txtSave.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("ExcelFile ����");
			alert.setHeaderText("�ֹ� ���� ExcelFile ���� ����");
			alert.setContentText("�ֹ� ���� ExcelFile �� �����Ǿ����ϴ�.\n�����Ͻ� ��η� �� Ȯ�����ּ���");
			alert.showAndWait();
		}
		txtSave.clear();
		btnExcel.setDisable(true);

	}

	// ���� â
	public void setPrimarStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	public void handlerCbS_NumAction(ActionEvent event) {
		OrderDAO oDao = new OrderDAO();

		if (cbS_Num.getSelectionModel().isEmpty()) {

		} else {

			txtSName.setText(oDao.getStoreName(cbS_Num.getSelectionModel().getSelectedItem()));
		}
	}

	public void handlerCbD_NumAction(ActionEvent event) {
		OrderDAO oDao = new OrderDAO();
		OrderVO ovo = new OrderVO();
		ArrayList<OrderVO> list;

		if (cbD_Num.getSelectionModel().isEmpty()) {

		} else {

			list = oDao.getDInformation(cbD_Num.getSelectionModel().getSelectedItem());

			txtItem.setText(list.get(0).getItem());
			txtStandard.setText(list.get(0).getStandard());
			txtVatBasePrice.setText(list.get(0).getCbVatBasePrice() + "");
		}
	}

	// ��ü����Ʈ �ҷ�����
	public void handlerAllAciton(ActionEvent event) {
		data.removeAll(data);
		totalList();
	}

	// �ʱ�ȭ ��ư
	public void handlerInitAction(ActionEvent event) {
		txtSName.clear();
		txtSName.setEditable(true);
		txtDelivery.clear();
		txtDelivery.setEditable(true);
		txtDestination.clear();
		txtDestination.setEditable(true);
		dpOrderDate.setValue(LocalDate.now());
		cbCollection.getSelectionModel().clearSelection();
		txtItem.clear();
		txtItem.setEditable(true);
		txtStandard.clear();
		txtStandard.setEditable(true);
		txtVatBasePrice.clear();
		txtVatBasePrice.setEditable(true);
		cbS_Num.getSelectionModel().clearSelection();
		cbD_Num.getSelectionModel().clearSelection();
		txtDisCount.clear();
		txtDisCount.setEditable(true);
		txtSell.clear();
		txtSell.setEditable(true);
		txtQuantity.clear();
		txtQuantity.setEditable(true);
		txtTotal.clear();
		txtTotal.setEditable(true);
		dpS_Search.setValue(LocalDate.now());
		dpA_Search.setValue(LocalDate.now());
		txtSearchName.clear();
		txtSearchName.setEditable(true);
		cbOrderState.getSelectionModel().clearSelection();
	}

	// �ֹ��������¼���
	public void handlerStateChangeAction(ActionEvent event) {
		try {

			OrderVO ovo = new OrderVO();
			OrderDAO odao = null;

			if (event.getSource().equals(btnStateChange)) {

				ovo = tableView.getSelectionModel().getSelectedItem();
				if (cbOrderState.getValue() != null) {
					odao = new OrderDAO();
					odao.getOrderStateUpdate(ovo, cbOrderState.getSelectionModel().getSelectedItem());
				}

			}
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�ֹ� ���� ���� ");
			alert.setHeaderText("�ֹ� ���¸� Ȯ�����ּ���");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
			System.out.println("�ֹ���������");
		}
	}

	// ������Ȳ��Ʈ
	public void handlerViewChartAction(ActionEvent event) {
		try {
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnRegist.getScene().getWindow());
			dialog.setTitle("���� �׷���");

			Parent parent = FXMLLoader.load(getClass().getResource("/view/barchart.fxml"));

			BarChart barChart = (BarChart) parent.lookup("#barChart");

			XYChart.Series SalesJanuary = new XYChart.Series();
			SalesJanuary.setName("1��");
			ObservableList January = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {
				double totalPrice = 0;
				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("01")) {
						totalPrice = totalPrice + data.get(j).getTotal_money();
					}
				}
				January.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));
			}
			SalesJanuary.setData(January);
			barChart.getData().add(SalesJanuary);

			XYChart.Series SalesFebruary = new XYChart.Series();
			SalesFebruary.setName("2��");
			ObservableList February = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {
				double totalPrice = 0;
				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("02")) {
						totalPrice = totalPrice + data.get(j).getTotal_money();
					}

				}
				February.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));
			}
			SalesFebruary.setData(February);
			barChart.getData().add(SalesFebruary);

			XYChart.Series SalesMarch = new XYChart.Series<>();
			SalesMarch.setName("3��");
			ObservableList March = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("03")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				March.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesMarch.setData(March);
			barChart.getData().add(SalesMarch);

			XYChart.Series SalesApril = new XYChart.Series<>();
			SalesApril.setName("4��");
			ObservableList April = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("04")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				April.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesApril.setData(April);
			barChart.getData().add(SalesApril);

			XYChart.Series SalesMay = new XYChart.Series<>();
			SalesMay.setName("5��");
			ObservableList May = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("05")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				May.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesMay.setData(May);
			barChart.getData().add(SalesMay);

			XYChart.Series SalesJune = new XYChart.Series<>();
			SalesJune.setName("6��");
			ObservableList June = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("06")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				June.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesJune.setData(June);
			barChart.getData().add(SalesJune);

			XYChart.Series SalesJuly = new XYChart.Series<>();
			SalesJuly.setName("7��");
			ObservableList July = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("07")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				July.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesJuly.setData(July);
			barChart.getData().add(SalesJuly);

			XYChart.Series SalesAugust = new XYChart.Series<>();
			SalesAugust.setName("8��");
			ObservableList August = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("08")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				August.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesAugust.setData(August);
			barChart.getData().add(SalesAugust);

			XYChart.Series SalesSeptember = new XYChart.Series<>();
			SalesSeptember.setName("9��");
			ObservableList September = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("09")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				September.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesSeptember.setData(September);
			barChart.getData().add(SalesSeptember);

			XYChart.Series SalesOctober = new XYChart.Series<>();
			SalesOctober.setName("10��");
			ObservableList October = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("10")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				October.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesOctober.setData(October);
			barChart.getData().add(SalesOctober);

			XYChart.Series SalesNovember = new XYChart.Series<>();
			SalesNovember.setName("11��");
			ObservableList November = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("11")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				November.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesNovember.setData(November);
			barChart.getData().add(SalesNovember);

			XYChart.Series SalesDecember = new XYChart.Series<>();
			SalesDecember.setName("12��");
			ObservableList December = FXCollections.observableArrayList();
			for (int i = 0; i < data.size(); i++) {

				double totalPrice = 0;

				for (int j = 0; j < data.size(); j++) {

					if (data.get(j).getOrder_date().toString().substring(0, 4)
							.equals(data.get(i).getOrder_date().toString().substring(0, 4))
							&& (data.get(j).getApprovalstatus().equals("���οϷ�"))
							&& data.get(j).getOrder_date().toString().substring(5, 7).equals("12")) {

						totalPrice = totalPrice + data.get(j).getTotal_money();

					}

				}

				December.add(new XYChart.Data(data.get(i).getOrder_date().toString().substring(0, 4), totalPrice));

			}
			SalesDecember.setData(December);
			barChart.getData().add(SalesDecember);

			Button btnClose = (Button) parent.lookup("#btnClose");
			btnClose.setOnAction(e -> dialog.close());

			Scene scene = new Scene(parent);
			dialog.setScene(scene);
			dialog.show();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void handlerSearchNameAction(ActionEvent event) {
		OrderVO ovo = new OrderVO();
		OrderDAO oDao = null;

		Object[][] totalData = null;
		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txtSearchName.getText().trim();
			oDao = new OrderDAO();
			ovo = oDao.getOrderSearch(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("�ֹ� ���� �˻�");
				alert.setHeaderText("���Ż� �̸��� ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (ovo != null)) {
				ArrayList<String> title;
				ArrayList<OrderVO> list;

				title = oDao.getColumnName();
				int columnCount = title.size();

				list = oDao.getOrderTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (ovo.getS_name().equals(searchName)) {
					txtSearchName.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						ovo = list.get(index);
						if (ovo.getS_name().equals(searchName)) {
							data.add(ovo);
							searchResult = true;

						}
					}
				}
			}
			if (!searchResult) {
				txtSearchName.clear();
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("�ֹ� ���� �˻�");
				alert.setHeaderText(searchName + "�ֹ� ������ ã�� �� �����ϴ�");
				alert.setContentText("�ٽ� �˻����ּ���!");
				alert.showAndWait();
			}
		} catch (Exception e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�ֹ� ���� �˻� ����");
			alert.setHeaderText("�ֹ� ������ ���� �� �� �����ϴ�");
			alert.setContentText("�ٽ� �˻����ּ���!");
			alert.showAndWait();
			System.out.println("0909");
		}

	}

	// ��¥ ������ȸ
	public void handlerSearchDateAction(ActionEvent event) throws Exception {
		try {
			data.removeAll(data);

			OrderDAO oDao = new OrderDAO();
			System.out.println(oDao.getSearchDate(dpS_Search.getValue(), dpA_Search.getValue()).get(0).getD_num());
			data.addAll(oDao.getSearchDate(dpS_Search.getValue(), dpA_Search.getValue()));

			if (data != null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ����� �˻�");
				alert.setHeaderText("�ֹ����� �˻��� �Ϸ�Ǿ����ϴ�");
				alert.setContentText("�ֹ������˻� ����!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("�ֹ����� �˻� �˻�");
				alert.setHeaderText("�ֹ���¥�� Ȯ�����ּ���");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();

			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// ������ư
	public void handlerDeleteAction(ActionEvent event) {
		OrderDAO oDao = new OrderDAO();
		try {
			oDao.getOrderDelete(tableView.getSelectionModel().getSelectedItem().getOrder_num());
			data.removeAll(data);
			totalList();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// �հ�ݾ� ���
	public void handlerTotalAction(ActionEvent event) {
		double Quantity = Double.parseDouble(txtQuantity.getText().trim());
		// �հ�ݾ� = �ǸŰ� * ����
		order.setTotal_money(order.getSelling() * Quantity);
		// Math.round�� �̿��� �Ҽ��� �ݿø����
		txtTotal.setText(Math.round(order.getTotal_money()) + "");
	}

	// �ǸŰ��ݰ��
	public void handlerSellAction(ActionEvent event) {
		try {
			int baseprice = Integer.parseInt(txtVatBasePrice.getText().trim());
			int discount = Integer.parseInt(txtDisCount.getText().trim());
			double sell;
			// �ǸŰ� = ��ǰ���ذ���(VAT) - (���ذ��� * (������ * 0.01))
			sell = baseprice - (baseprice * (discount * 0.01));

			order.setSelling(sell);

			txtSell.setText(order.getSelling() + "");

		} catch (Exception e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�ǸŰ� ���� ���");
			alert.setHeaderText("���ؾ�ǰ���ݰ� �������� Ȯ�����ּ���");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();

		}
	}

	// ��Ϲ�ư
	public void handlerRegistAction(ActionEvent event) {
		try {
			data.removeAll(data);
			OrderVO orv = null;
			OrderDAO oDao = null;
			int i = 0;

			if (event.getSource().equals(btnRegist)) {
				orv = new OrderVO(cbS_Num.getSelectionModel().getSelectedItem(),
						cbD_Num.getSelectionModel().getSelectedItem(), txtDelivery.getText(), txtDestination.getText(),
						dpOrderDate.getValue(), Integer.parseInt(txtDisCount.getText()),
						Double.parseDouble(txtSell.getText()), Double.parseDouble(txtTotal.getText()),
						cbCollection.getSelectionModel().getSelectedItem(), Integer.parseInt(txtQuantity.getText()),
						cbOrderState.getSelectionModel().getSelectedItem(), txtStandard.getText(), txtSName.getText(),
						txtItem.getText(), Integer.parseInt(txtVatBasePrice.getText()));

				oDao = new OrderDAO();
				i = oDao.getOrderInput(orv);
				if (i == 1) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("�ֹ����� ���");
					alert.setHeaderText("�ֹ����� ��� ����");
					alert.setContentText("�ֹ����� ��� ����!!!");
					alert.showAndWait();
					handlerInitAction(event);

				} else {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("�ֹ����� ��� ����");
					alert.setHeaderText("�ֹ����� ��� ����");
					alert.setContentText("�ֹ����� ��� ����!!!");
					alert.showAndWait();
				}

			}

			totalList();

		} catch (Exception e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�ֹ����� ��� ����");
			alert.setHeaderText("�ֹ����� ��� ����");
			alert.setContentText("�ֹ����� ��� ����!!!");
			alert.showAndWait();
			totalList();

		}

	}

	// �÷��� ���ڵ� �ҷ�����
	public void totalList() {
		Object[][] totalData;

		OrderDAO oDao = new OrderDAO();
		OrderVO ovo = null;

		ArrayList<String> title;
		ArrayList<OrderVO> list;

		title = oDao.getColumnName();
		int columnCount = title.size();

		list = oDao.getOrderTotal();

		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			ovo = list.get(index);
			data.add(ovo);
		}

	}

	// ��ҹ�ư
	public void handlerExitAciton(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
			Scene scene = new Scene(root);
			Stage primaryStage = new Stage();

			Stage oldStage = (Stage) btnExit.getScene().getWindow();
			oldStage.close();
			primaryStage.setTitle("�ѱ����� �ֹ�����");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
