package controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.plaf.synth.SynthSpinnerUI;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.StoreVO;

public class StoreController implements Initializable {
	@FXML
	private TableView<StoreVO> tableView = new TableView<>();
	@FXML
	private Button btnInit;
	@FXML
	private TextField txtName;
	@FXML
	private TextField txtBoss;
	@FXML
	private TextField txtPhone;
	@FXML
	private TextField txtAddress;
	@FXML
	private TextField txtBusinessNum;
	@FXML
	private Button btnRegist;
	@FXML
	private Button btnChange;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnExit;
	@FXML
	private TextField txtSearch;
	@FXML
	private Button btnSearch;
	@FXML
	private Button btnAll;

	int s_num;
	StoreVO store = new StoreVO();
	ObservableList<StoreVO> data = FXCollections.observableArrayList();
	ObservableList<StoreVO> selectStore;
	boolean editDelete = false; // ������ �� ��Ϲ�ư ���� ����
	int selectedIndex; // ���̺����� ������ �л� ���� �ε��� ����

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		tableView.setEditable(false);
		tableView.setItems(data);

		btnRegist.setOnAction(event -> handlerRegistAction(event));
		btnChange.setOnAction(event -> handlerChangeAction(event));
		btnDelete.setOnAction(event -> handlerDeleteAction(event));
		btnExit.setOnAction(event -> handlerExitAction(event));
		btnSearch.setOnAction(event -> handlerSearchAction(event));
		btnAll.setOnAction(event -> handlerbtnAllAciton(event));
		btnInit.setOnAction(event -> handlerbtnInitAction(event));

		TableColumn colNo = new TableColumn("NO.");
		colNo.setMinWidth(21);
		colNo.setStyle("-fx-alignment:CENTER");
		colNo.setCellValueFactory(new PropertyValueFactory<>("s_num"));

		TableColumn colName = new TableColumn("�ŷ�ó��");
		colName.setMinWidth(110);
		colName.setStyle("-fx-alignment:CENTER");
		colName.setCellValueFactory(new PropertyValueFactory<>("s_name"));

		TableColumn colBoss = new TableColumn("����ڸ�");
		colBoss.setMinWidth(84);
		colBoss.setStyle("-fx-alignment:CENTER");
		colBoss.setCellValueFactory(new PropertyValueFactory<>("s_boss"));

		TableColumn colPhone = new TableColumn("����ó");
		colPhone.setMinWidth(113);
		colPhone.setStyle("-fx-alignment:CENTER");
		colPhone.setCellValueFactory(new PropertyValueFactory<>("s_phone"));

		TableColumn colAddress = new TableColumn("�ŷ�ó�ּ�");
		colAddress.setMinWidth(105);
		colAddress.setStyle("-fx-alignment:CENTER");
		colAddress.setCellValueFactory(new PropertyValueFactory<>("s_address"));

		TableColumn colBusinessNum = new TableColumn("����ڹ�ȣ");
		colBusinessNum.setMinWidth(137);
		colBusinessNum.setStyle("-fx-alignment:CENTER");
		colBusinessNum.setCellValueFactory(new PropertyValueFactory<>("s_businessnum"));

		tableView.setItems(data);
		tableView.getColumns().addAll(colNo, colName, colBoss, colPhone, colAddress, colBusinessNum);

		totalList();

		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				try {
					txtName.setText(tableView.getSelectionModel().getSelectedItem().getS_name());
					txtBoss.setText(tableView.getSelectionModel().getSelectedItem().getS_boss());
					txtPhone.setText(tableView.getSelectionModel().getSelectedItem().getS_phone());
					txtAddress.setText(tableView.getSelectionModel().getSelectedItem().getS_address());
					txtBusinessNum.setText(tableView.getSelectionModel().getSelectedItem().getS_businessnum());
				} catch (Exception e) {
					System.out.println(e);
				}
			}

		});

	}

	public void handlerbtnInitAction(ActionEvent event) {
		init();
	}

	public void handlerbtnAllAciton(ActionEvent event) {
		try {
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerSearchAction(ActionEvent event) {
		StoreVO sVo = new StoreVO();
		StoreDAO sDao = null;

		Object[][] totalData = null;

		String searchName = "";
		boolean searchResult = false;

		try {
			searchName = txtSearch.getText().trim();
			sDao = new StoreDAO();
			sVo = sDao.getStoreCheck(searchName);

			if (searchName.equals("")) {
				searchResult = true;
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("���Ż� ���� �˻�");
				alert.setHeaderText("���Ż� ������ ��Ȯ�� �Է��Ͻÿ�.");
				alert.setContentText("�������� �����ϼ���!");
				alert.showAndWait();
			}

			if (!searchName.equals("") && (sVo != null)) {
				ArrayList<String> title;
				ArrayList<StoreVO> list;

				title = sDao.getColumnName();
				int columnCount = title.size();

				list = sDao.getStoreTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if (sVo.getS_name().equals(searchName)) {
					txtSearch.clear();
					data.removeAll(data);
					for (int index = 0; index < rowCount; index++) {
						sVo = list.get(index);
						if (sVo.getS_name().equals(searchName)) {
							data.add(sVo);
							searchResult = true;
						}
					}
				}
			}

			if (!searchResult) {
				txtSearch.clear();
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("���Ż� ���� �˻�");
				alert.setHeaderText(searchName + "���Ż� ������ ã�� �� �����ϴ�");
				alert.setContentText("�ٽ� �˻����ּ���!");
				alert.showAndWait();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("���Ż� ���� �˻� ����");
			alert.setHeaderText("���Ż� ������ ���� �� �� �����ϴ�");
			alert.setContentText("�ٽ� �˻����ּ���!");
			alert.showAndWait();
		}
	}

	public void init() {
		txtName.clear();
		txtName.setEditable(true);
		txtBoss.clear();
		txtBoss.setEditable(true);
		txtPhone.clear();
		txtPhone.setEditable(true);
		txtAddress.clear();
		txtAddress.setEditable(true);
		txtBusinessNum.clear();
		txtBusinessNum.setEditable(true);
	}

	public void totalList() {
		Object[][] totalData;

		StoreDAO sDao = new StoreDAO();
		StoreVO svo = null;
		;

		ArrayList<String> title;
		ArrayList<StoreVO> list;

		title = sDao.getColumnName();
		int columnCount = title.size();

		list = sDao.getStoreTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			svo = list.get(index);
			data.add(svo);
		}
	}

	public void handlerExitAction(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/view/main.fxml"));
			Scene scene = new Scene(root);
			Stage primaryStage = new Stage();

			Stage oldStage = (Stage) btnRegist.getScene().getWindow();
			oldStage.close();
			primaryStage.setTitle("�ѱ����� �ֹ�����");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerDeleteAction(ActionEvent event) {
		StoreDAO sDao = new StoreDAO();
		try {

			sDao.getStoreDelete(tableView.getSelectionModel().getSelectedItem().getS_num());
			data.removeAll(data);
			totalList();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void handlerChangeAction(ActionEvent event) {

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/storechange.fxml"));
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnRegist.getScene().getWindow());
			dialog.setTitle("���Ż� ���� ����");

			Parent parentEdit = (Parent) loader.load();
			StoreVO storeChange = tableView.getSelectionModel().getSelectedItem();
			selectedIndex = tableView.getSelectionModel().getSelectedIndex();

			TextField ChangeNum = (TextField) parentEdit.lookup("#txtNum");
			TextField ChangeName = (TextField) parentEdit.lookup("#txtName");
			TextField ChangeBoss = (TextField) parentEdit.lookup("#txtBoss");
			TextField ChangePhone = (TextField) parentEdit.lookup("#txtPhone");
			TextField ChangeAddress = (TextField) parentEdit.lookup("#txtAddress");
			TextField ChangeBusinessNum = (TextField) parentEdit.lookup("#txtBusinessNum");

			ChangeNum.setDisable(true);

			ChangeNum.setText(storeChange.getS_num() + "");
			ChangeName.setText(storeChange.getS_name());
			ChangeBoss.setText(storeChange.getS_boss());
			ChangePhone.setText(storeChange.getS_phone());
			ChangeAddress.setText(storeChange.getS_address());
			ChangeBusinessNum.setText(storeChange.getS_businessnum());

			Button btnRegistAdd = (Button) parentEdit.lookup("#btnRegist");
			Button btnExit = (Button) parentEdit.lookup("#btnExit");

			btnRegistAdd.setOnAction(e -> {

				if (ChangeName.getText().equals("") || ChangeBoss.getText().equals("")
						|| ChangePhone.getText().equals("") || ChangeAddress.getText().equals("")
						|| ChangeBusinessNum.getText().equals("")) {

					Alert alert = new Alert(AlertType.ERROR);
					alert.setTitle("���Ż� ���� ����");
					alert.setHeaderText("���Ż� ������ ��Ȯ�� �Է��Ͻÿ�.");
					alert.setContentText("�������� �����ϼ���!");
					alert.showAndWait();

				} else {
					StoreVO svo = new StoreVO();
					StoreDAO sDao = new StoreDAO();

					try {
						svo = new StoreVO(Integer.parseInt(ChangeNum.getText()), ChangeName.getText(),
								ChangeBoss.getText(), ChangePhone.getText(), ChangeAddress.getText(),
								ChangeBusinessNum.getText());
						sDao = new StoreDAO();
						sDao.getStoreUpdate(svo, svo.getS_num());
						data.removeAll(data);
						totalList();

					} catch (Exception e1) {
						e1.printStackTrace();
						System.out.println("ggg");
					}
				}
			});
			btnExit.setOnAction(e -> {
				dialog.close();
			});
			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("1123456");
		}
	}

	public void handlerRegistAction(ActionEvent event) {

		int i = 0;

		data.removeAll(data);
		StoreVO stv = new StoreVO();
		StoreDAO sdao = new StoreDAO();

		if (event.getSource().equals(btnRegist)) {
			stv = new StoreVO(txtName.getText(), txtBoss.getText(), txtPhone.getText(), txtAddress.getText(),
					txtBusinessNum.getText());

			if (sdao != null) {
			}

			sdao = new StoreDAO();
			i = sdao.getStoreVOInformation(stv);

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���Ż� ���� �Է�");
				alert.setHeaderText("���Ż� ���� ��� �Ϸ�.");
				alert.setContentText("���Ż� ���� ��� ����!!!");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("���Ż� ���� ���");
				alert.setHeaderText("���Ż� ���� ��� ����.");
				alert.setContentText("���Ż� ���� ��� ����!!!");
				alert.showAndWait();
			}

			totalList();
			init();

		} else {

		}

	}

}
