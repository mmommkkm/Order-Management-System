package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.OrderVO;

public class OrderDAO {

	public OrderVO getOrderStateUpdate(OrderVO orv, String state) throws Exception {
		String sql = "update purchase_order set approvalstatus = ? where order_num = ?";
				
		Connection con = null;
		PreparedStatement pstmt = null;
		OrderVO orvo = null;

		try {
			con = DBUtil.getConnection();
			pstmt =con.prepareStatement(sql);
			pstmt.setString(1, state);
			pstmt.setInt(2, orv.getOrder_num());
			
			int i = pstmt.executeUpdate();
			System.out.println(i);
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ����� ����");
				alert.setHeaderText("�ֹ����� ���� �Ϸ�");
				alert.setContentText("�ֹ����� ����");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("�ֹ����� ����");
				alert.setHeaderText("�ֹ����� ���� ����");
				alert.setContentText("�ֹ����� ���� ����!!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return orvo;
	}
	
	public void getOrderDelete(int order_num) throws Exception {
		String sql = "delete from purchase_order where order_num = ?";

		Connection con = null;
		PreparedStatement pstmt = null;

		try {

			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, order_num);
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ֹ� ����");
				alert.setHeaderText("�ֹ� ���� ����");
				alert.setContentText("�ֹ� ���� ����!!!");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.ERROR);
				alert.setTitle("�ֹ� ����");
				alert.setHeaderText("�ֹ� ���� ����");
				alert.setContentText("�ֹ� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}
	//���� �˻�(��¥�� ��¥������ �����˻�)
	public ArrayList<OrderVO> getSearchDate(LocalDate sdate, LocalDate adate) throws Exception {
		ArrayList<OrderVO> adv = new ArrayList<OrderVO>();

		String sql = "select order_num, s_name, deliveryplace, destination, order_date, item, standard,"
				+ " collection, vatbaseprice, discount, selling, quantity, total_money, approvalstatus"
				+ " from purchase_order p, company_drug d, store s  "
				+ "where p.d_num = d.d_num and p.s_num = s.s_num"
				+ " and order_date between to_date(?,'yyyy/mm/dd') and to_date(?,'yyyy/mm/dd')";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		OrderVO ovo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

				
			pstmt.setString(1, sdate.toString());
			pstmt.setString(2, adate.toString());

			rs = pstmt.executeQuery();
			while (rs.next()) {
				ovo = new OrderVO();
				ovo.setOrder_num(rs.getInt("order_num"));
				ovo.setDeliveryplace(rs.getString("deliveryplace"));
				ovo.setDestination(rs.getString("destination"));
				ovo.setOrder_date(rs.getDate("order_date").toLocalDate());
				ovo.setDiscount(rs.getInt("discount"));
				ovo.setSelling(rs.getDouble("selling"));
				ovo.setTotal_money(rs.getDouble("total_money"));
				ovo.setCollection(rs.getString("collection"));
				ovo.setQuantity(rs.getInt("quantity"));
				ovo.setApprovalstatus(rs.getString("approvalstatus"));
				ovo.setStandard(rs.getString("standard"));
				ovo.setS_name(rs.getString("s_name"));
				ovo.setItem(rs.getString("item"));
				ovo.setCbVatBasePrice(rs.getInt("vatbaseprice"));
				adv.add(ovo);

			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

		return adv;
	}

	public OrderVO getOrderSearch(String s_name) throws Exception {
		String sql = "select p.order_num, s.s_name, p.deliveryplace, p.destination, p.order_date, d.item, d.standard,"
				+ " p.collection, d.vatbaseprice, p.discount, p.selling, p.quantity, p.total_money, p.approvalstatus"
				+ " from purchase_order p, company_drug d, store s " + " where s.s_name = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		OrderVO orvo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, s_name);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				orvo = new OrderVO();
				orvo.setOrder_num(rs.getInt("order_num"));
				orvo.setDeliveryplace(rs.getString("deliveryplace"));
				orvo.setDestination(rs.getString("destination"));
				orvo.setOrder_date(rs.getDate("order_date").toLocalDate());
				orvo.setDiscount(rs.getInt("discount"));
				orvo.setSelling(rs.getDouble("selling"));
				orvo.setTotal_money(rs.getDouble("total_money"));
				orvo.setCollection(rs.getString("collection"));
				orvo.setQuantity(rs.getInt("quantity"));
				orvo.setApprovalstatus(rs.getString("approvalstatus"));
				orvo.setStandard(rs.getString("standard"));
				orvo.setS_name(rs.getString("s_name"));
				orvo.setItem(rs.getString("item"));
				orvo.setCbVatBasePrice(rs.getInt("cbVatBasePrice"));
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e1) {
				System.out.println(e1);
			}
		}

		return orvo;
	}
	
	

	public ArrayList<String> getStandard() {
		// ��ǰ�԰� �ҷ�����
		ArrayList<String> standard = new ArrayList<String>();

		String sql = "select standard from company_drug";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				standard.add(rs.getString(1));

			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return standard;

	}
	
	//��ǰ�Ϸù�ȣ �ҷ�����
	public ArrayList<String> getD_Num() {

		ArrayList<String> DNum = new ArrayList<String>();

		String sql = "select d_num from company_drug";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				DNum.add(rs.getString(1));

			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				System.out.println(e);
			}
		}
		return DNum;

	}
	//��ǰ���ݺҷ�����
	public ArrayList<Integer> getDrugPrice() {

		ArrayList<Integer> drugPrice = new ArrayList<Integer>();

		String sql = "select vatbaseprice from company_drug";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				drugPrice.add(rs.getInt(1));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return drugPrice;
	}
	//��ǰ�� �ҷ�����
	public ArrayList<String> getDrugName() {

		ArrayList<String> ename = new ArrayList<String>();

		String sql = "select item from company_drug";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ename.add(rs.getString(1));
			}

		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}

		}
		return ename;
	}
	
	//���Ż��Ϸù�ȣ �ҷ�����
		public ArrayList<Integer> getS_num() {

			ArrayList<Integer> SNum = new ArrayList<Integer>();

			String sql = "select s_num from store";

			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			try {
				con = DBUtil.getConnection();
				pstmt = con.prepareStatement(sql);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					SNum.add(rs.getInt(1));
				}

			} catch (SQLException e) {
				System.out.println(e);
			} catch (Exception e) {
				System.out.println(e);
			}

			return SNum;
		}
		
	public ArrayList<OrderVO> getDInformation(String d_num) {
		ArrayList<OrderVO> list = new ArrayList<OrderVO>();
		OrderVO ovo = new OrderVO();
		
		String sql ="select item, standard, vatbaseprice"
				 +" from company_drug"
				 +" where d_num = ?";
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, d_num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				ovo.setItem(rs.getString(1));
				ovo.setStandard(rs.getString(2));
				ovo.setCbVatBasePrice(rs.getInt(3));
				list.add(ovo);
				
			}
			
		}catch(SQLException e) {
			System.out.println(e);
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			try{
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(con != null)
					con.close();
			}catch(Exception e) {
				System.out.println(e.getStackTrace());
			}
		}
		return list;
	}
		
	//���Ż�� �ҷ�����
	public String getStoreName(int s_num) {
		
		String sql = "select s_name "
					+ "from store"
					+ " where s_num = ?";
		String s_name = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, s_num);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				
				s_name = rs.getString(1);
				
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (Exception e) {
				System.out.println(e.getStackTrace());
			}
		}
		
		return s_name;
		
	}
	//�ֹ����� �Է�
	public int getOrderInput(OrderVO orv) {

		String sql = "insert into purchase_order values(purchase_order_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int i = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, orv.getS_num());
			pstmt.setString(2, orv.getD_num());
			pstmt.setString(3, orv.getDeliveryplace());
			pstmt.setString(4, orv.getDestination());
			pstmt.setString(5, orv.getOrder_date().toString());
			pstmt.setInt(6, orv.getDiscount());
			pstmt.setDouble(7, orv.getSelling());
			pstmt.setDouble(8, orv.getTotal_money());
			pstmt.setString(9, orv.getCollection());
			pstmt.setInt(10, orv.getQuantity());
			pstmt.setString(11, orv.getApprovalstatus());

			i = pstmt.executeUpdate();

		} catch (SQLException e) {
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return i;

	}
	//�ֹ����ȭ�� �÷� �ҷ�����
	public ArrayList<OrderVO> getOrderTotal() {
		ArrayList<OrderVO> list = new ArrayList<OrderVO>();
		String tml = "select p.order_num, s.s_name, p.deliveryplace, p.destination, p.order_date, d.item, d.standard,"
				+ " p.collection, d.vatbaseprice, p.discount, p.selling, p.quantity, p.total_money, p.approvalstatus"
				+ " from purchase_order p, company_drug d, store s " 
				+" where s.s_num = p.s_num AND p.d_num = d.d_num order by p.order_date";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		OrderVO orvo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
		
			
			
			while (rs.next()) {
				orvo = new OrderVO();
				orvo.setOrder_num(rs.getInt(1));
				orvo.setDeliveryplace(rs.getString(3));
				orvo.setDestination(rs.getString(4));
				orvo.setOrder_date(rs.getDate(5).toLocalDate());
				orvo.setDiscount(rs.getInt(10));
				orvo.setSelling(rs.getDouble(11));
				orvo.setTotal_money(rs.getDouble(13));
				orvo.setCollection(rs.getString(8));
				orvo.setQuantity(rs.getInt(10));
				orvo.setApprovalstatus(rs.getString(14));
				orvo.setStandard(rs.getString(7));
				orvo.setS_name(rs.getString(2));
				orvo.setItem(rs.getString(6));
				orvo.setCbVatBasePrice(rs.getInt(9));
				
						list.add(orvo);
			
			
			

/*
 * 
 * 				
				
				orvo.setOrder_num(rs.getInt("p.order_num"));
				orvo.setDeliveryplace(rs.getString("p.deliveryplace"));
				orvo.setDestination(rs.getString("p.destination"));
				orvo.setOrder_date(rs.getDate("p.order_date").toLocalDate());
				orvo.setDiscount(rs.getInt("d.discount"));
				orvo.setSelling(rs.getDouble("d.selling"));
				orvo.setTotal_money(rs.getDouble("p.total_money"));
				orvo.setCollection(rs.getString("p.collection"));
				orvo.setQuantity(rs.getInt("p.quantity"));
				orvo.setApprovalstatus(rs.getString("p.approvalstatus"));
				orvo.setStandard(rs.getString("d.standard"));
				orvo.setS_name(rs.getString("s.s_name"));
				orvo.setItem(rs.getString("d.item"));
				orvo.setCbVatBasePrice(rs.getInt("d.vatbaseprice"));
				
							rs.getString(2),
								rs.getString(3),
								rs.getString(4),
								rs.getDate(5).toLocalDate(),
								rs.getInt(6),
								rs.getDouble(7),
								rs.getDouble(8),
								rs.getString(9),
								rs.getInt(10),
								rs.getString(11),
								rs.getString(12),
								rs.getString(13),
								rs.getString(14),
								rs.getInt(15));	*/
				
			}

		} catch (SQLException e) {
			System.out.println("1212");
			System.out.println(e);
		} catch (Exception e) {
			System.out.println("2323");
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				System.out.println(e);

			}
		}
		return list;
	}
	//�÷��ҷ�����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from purchase_order";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();

			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);

			}
		}
		return columnName;
	}

}
