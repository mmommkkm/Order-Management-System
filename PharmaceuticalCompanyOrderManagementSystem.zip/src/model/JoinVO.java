package model;

public class JoinVO {
	private String name;
	private String p_num;
	private String p_phone;
	private String id;
	private String password;

	
	
	
	public JoinVO(String id, String password) {
		this.id = id;
		this.password = password;
	}

	

	public JoinVO(String id) {
		this.id = id;
	}



	public JoinVO() {
	}



	public JoinVO(String id, String password, String name, String p_num, String p_phone) {
		this.id = id;
		this.password = password;
		this.name = name;
		this.p_num = p_num;
		this.p_phone = p_phone;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getP_num() {
		return p_num;
	}



	public void setP_num(String p_num) {
		this.p_num = p_num;
	}



	public String getP_phone() {
		return p_phone;
	}



	public void setP_phone(String p_phone) {
		this.p_phone = p_phone;
	}
	
	
	
}
