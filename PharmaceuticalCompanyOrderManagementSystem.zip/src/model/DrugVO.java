package model;

public class DrugVO {
	private String d_num;
	private String item;
	private String standard;
	private int vatbaseprice;
	
	
	
	public DrugVO(String d_num) {
		super();
		this.d_num = d_num;
	}



	public DrugVO() {
		super();
	}



	public DrugVO(String d_num, String item, String standard, int vatbaseprice) {
		super();
		this.d_num = d_num;
		this.item = item;
		this.standard = standard;
		this.vatbaseprice = vatbaseprice;
	}



	public String getD_num() {
		return d_num;
	}



	public void setD_num(String d_num) {
		this.d_num = d_num;
	}



	public String getItem() {
		return item;
	}



	public void setItem(String item) {
		this.item = item;
	}



	public String getStandard() {
		return standard;
	}



	public void setStandard(String standard) {
		this.standard = standard;
	}



	public int getVatbaseprice() {
		return vatbaseprice;
	}



	public void setVatbaseprice(int vatbaseprice) {
		this.vatbaseprice = vatbaseprice;
	}
	
	
}