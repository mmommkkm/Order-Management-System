package model;

import java.time.LocalDate;

public class OrderVO {
	private int order_num;
	
	private int s_num;
	private String d_num;
	private String deliveryplace;
	private String destination;
	private LocalDate order_date;
	private int discount;
	private double selling;
	private double total_money;
	private String collection;
	private int quantity;
	private String approvalstatus;
	private String standard;
	private String s_name;
	private String item;
	private int cbVatBasePrice;
	
	
	
	
	
	
	
	public OrderVO(String approvalstatus) {
		this.approvalstatus = approvalstatus;
	}
	public OrderVO(int order_num, String deliveryplace, String destination, LocalDate order_date, int discount,
			double selling, double total_money, String collection, int quantity, String approvalstatus, String standard,
			String s_name, String item, int cbVatBasePrice) {
		super();
		this.order_num = order_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.approvalstatus = approvalstatus;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public OrderVO(int order_num, 
			String deliveryplace, 
			String destination, 
			LocalDate order_date, 
			int discount,
			double selling, 
			double total_money, 
			String collection, 
			int quantity, 
			String standard, 
			String s_name,
			String item, 
			int cbVatBasePrice) {
		
		super();
		this.order_num = order_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public OrderVO(int order_num,
			int s_num,
			String d_num, 
			String deliveryplace,
			String destination,
			LocalDate order_date,
			int discount, 
			double selling,
			double total_money,
			String collection,
			int quantity,
			String approvalstatus,
			String standard,
			String s_name, 
			String item) {
		super();
		this.order_num = order_num;
		this.s_num = s_num;
		this.d_num = d_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.approvalstatus = approvalstatus;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
	}
	public OrderVO(int order_num, int s_num, String d_num, String deliveryplace, String destination,
			LocalDate order_date, int discount, double selling, double total_money, String collection, int quantity,
			String approvalstatus) {
		super();
		this.order_num = order_num;
		this.s_num = s_num;
		this.d_num = d_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.approvalstatus = approvalstatus;
	}
	public OrderVO(int s_num, String d_num, String deliveryplace, String destination, LocalDate order_date,
			int discount, double selling, double total_money, String collection, int quantity, String standard,
			String s_name, String item, int cbVatBasePrice) {
		super();
		this.s_num = s_num;
		this.d_num = d_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public OrderVO(int s_num, String d_num, String deliveryplace, String destination, LocalDate order_date,
			int discount, double selling, double total_money, String collection, int quantity, String approvalstatus,
			String standard, String s_name, String item, int cbVatBasePrice) {
		super();
		this.s_num = s_num;
		this.d_num = d_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.approvalstatus = approvalstatus;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public OrderVO(int order_num, int s_num, String d_num, String deliveryplace, String destination,
			LocalDate order_date, int discount, double selling, double total_money, String collection, int quantity,
			String approvalstatus, String standard, String s_name, String item, int cbVatBasePrice) {
		super();
		this.order_num = order_num;
		this.s_num = s_num;
		this.d_num = d_num;
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.approvalstatus = approvalstatus;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public OrderVO() {
		super();
	}
	public OrderVO(String deliveryplace, String destination, LocalDate order_date, int discount, double selling,
			double total_money, String collection, int quantity, String standard, String s_name, String item,
			int cbVatBasePrice) {
		super();
		this.deliveryplace = deliveryplace;
		this.destination = destination;
		this.order_date = order_date;
		this.discount = discount;
		this.selling = selling;
		this.total_money = total_money;
		this.collection = collection;
		this.quantity = quantity;
		this.standard = standard;
		this.s_name = s_name;
		this.item = item;
		this.cbVatBasePrice = cbVatBasePrice;
	}
	public int getOrder_num() {
		return order_num;
	}
	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	public String getD_num() {
		return d_num;
	}
	public void setD_num(String d_num) {
		this.d_num = d_num;
	}
	public String getDeliveryplace() {
		return deliveryplace;
	}
	public void setDeliveryplace(String deliveryplace) {
		this.deliveryplace = deliveryplace;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public LocalDate getOrder_date() {
		return order_date;
	}
	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public double getSelling() {
		return selling;
	}
	public void setSelling(double selling) {
		this.selling = selling;
	}
	public double getTotal_money() {
		return total_money;
	}
	public void setTotal_money(double total_money) {
		this.total_money = total_money;
	}
	public String getCollection() {
		return collection;
	}
	public void setCollection(String collection) {
		this.collection = collection;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getApprovalstatus() {
		return approvalstatus;
	}
	public void setApprovalstatus(String approvalstatus) {
		this.approvalstatus = approvalstatus;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public int getCbVatBasePrice() {
		return cbVatBasePrice;
	}
	public void setCbVatBasePrice(int cbVatBasePrice) {
		this.cbVatBasePrice = cbVatBasePrice;
	}
	
	



}
