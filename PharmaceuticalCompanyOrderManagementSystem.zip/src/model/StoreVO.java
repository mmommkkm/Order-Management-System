package model;

public class StoreVO {
	private int s_num;
	private String s_name;
	private String s_boss;
	private String s_phone;
	private String s_address;
	private String s_businessnum;
	
	
	
	public StoreVO(String s_name, String s_boss, String s_phone, String s_address, String s_businessnum) {
		super();
		this.s_name = s_name;
		this.s_boss = s_boss;
		this.s_phone = s_phone;
		this.s_address = s_address;
		this.s_businessnum = s_businessnum;
	}
	
	
	



	public StoreVO(int s_num) {
		super();
		this.s_num = s_num;
	}



	public StoreVO() {
		super();
	}



	public StoreVO(int s_num, String s_name, String s_boss, String s_phone, String s_address, String s_businessnum) {
		super();
		this.s_num = s_num;
		this.s_name = s_name;
		this.s_boss = s_boss;
		this.s_phone = s_phone;
		this.s_address = s_address;
		this.s_businessnum = s_businessnum;
	}



	public int getS_num() {
		return s_num;
	}



	public void setS_num(int s_num) {
		this.s_num = s_num;
	}



	public String getS_name() {
		return s_name;
	}



	public void setS_name(String s_name) {
		this.s_name = s_name;
	}



	public String getS_boss() {
		return s_boss;
	}



	public void setS_boss(String s_boss) {
		this.s_boss = s_boss;
	}



	public String getS_phone() {
		return s_phone;
	}



	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}



	public String getS_address() {
		return s_address;
	}



	public void setS_address(String s_address) {
		this.s_address = s_address;
	}



	public String getS_businessnum() {
		return s_businessnum;
	}



	public void setS_businessnum(String s_businessnum) {
		this.s_businessnum = s_businessnum;
	}
	
	
	
	
}
